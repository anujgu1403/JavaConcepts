function clickHandler() {
  document.getElementById("clcikMe").setAttribute("style", "color:red");
}

function paraMouseOver() {
  document.getElementById("pid").setAttribute("style", "color:green");
}

//document.getElementById("pid").addEventListener("mouseover", paraMouseOver);
//document.getElementById("clcikMe").addEventListener("click", clickHandler);

function validateForm() {
  var name = document.getElementById("name");
  var phone = document.getElementById("phone");
  if (name.value == "") {
    alert("Name can't be blank");
    document.getElementById("valMsg").setAttribute("style", "color:green");
    document.getElementById("valMsg").innerHTML = "Name can't be blank";
  }
  if (phone.value == "") {
    alert("Phone can't be blank");
    document.getElementById("valMsg").setAttribute("style", "color:green");
    document.getElementById("valMsg").innerHTML = "Phone can't be blank";
  }
}
