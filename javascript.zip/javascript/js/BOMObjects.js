function openWindowOP() {
  var newWindow = window.open(
    "https://www.gmail.com",
    "TestOpenWindow",
    "height=200,width=300"
  );
  newWindow.moveTo(400, 200);
  console.log("Closing window");
  newWindow.close();
}
openWindowOP();
//window.close();

function getNavigatorObj() {
  console.log(navigator);
  document.write("<br/> appcodename: " + navigator.appCodeName);
  document.write("<br/> appname: " + navigator.appName);
  document.write("<br/> appname: " + navigator.platform);
  document.write("<br/> appname: " + navigator.cookieEnabled);
  document.write("<br/> appname: " + navigator.product);
  console.log(location.hostname);
  console.log(location.href);
}
getNavigatorObj();
