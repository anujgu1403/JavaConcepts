//named function
function calSqure(a) {
  return a * a;
}

console.log("Calling named function: ", calSqure(10));

//Anonymous functions
var squre = function(a) {
  return a * a;
};

console.log("Calling Anonymous function: ", squre(12));

//new constuctor
var consFunc = new Function("a", "return a*a;");
console.log("Calling constuctor function: ", consFunc(13));

//self invoking function
(function(a) {
  console.log("Calling self invoking function");
  console.log(a * a);
  return a * a;
})(17);
