function createObjectMethod1() {
  var person = new Object();
  (person.name = "Anuj"), (person.age = 34);
  return person;
}

var Anuj = createObjectMethod1();
console.log("createObjectMethod1 : " + Anuj.name + " " + Anuj.age);

function createObjectMethod2() {
  var person = {};
  (person.name = "Gupta"), (person.age = 34);
  return person;
}

var Anuj = createObjectMethod2();
console.log("createObjectMethod2 : " + Anuj.name + " " + Anuj.age);

function createObjectMethod3() {
  var person = {};
  (person["name"] = "Mittal"), (person["age"] = 34);
  return person;
}

var Anuj = createObjectMethod3();
console.log("createObjectMethod3 : " + Anuj.name + " " + Anuj.age);

function createObjectMethod4() {
  var person = {
    name: "Anuj11",
    age: 32
  };
  return person;
}

var Anuj = createObjectMethod4();
console.log("createObjectMethod4 : " + Anuj.name + " " + Anuj.age);

function Person() {
  (this.name = "Anuj21"), (this.age = 33);
}

var obj = new Person();
console.log("createObjectMethod5 : " + obj.name + " " + obj.age);

var Animal = {
  type: "Invertable",
  displayType: function() {
    alert("this.type: " + this.type);
  }
};

var Hourse = Object.create(Animal);
Hourse.type = "Runner";
console.log(Hourse);
Hourse.displayType();

var Trainer = {
  name: "XYZ",
  subjects: ["Maths", "Science"],
  teaches: ["F", "S"],
  age: 35
};

var properties = "";
for (p in Trainer) {
  properties += p + ":";
}
console.log("before prop: " + properties);
//To delete the properties
delete Trainer.age;

var properties = "";
for (p in Trainer) {
  properties += p + ":";
}
console.log("after delete prop: " + properties);
